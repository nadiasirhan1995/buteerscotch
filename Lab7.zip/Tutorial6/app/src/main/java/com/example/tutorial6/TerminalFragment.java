
package com.example.tutorial6;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;

public class TerminalFragment extends Fragment implements SensorEventListener {

    private EditText stepsEditText;
    private EditText fileNameEditText;
    private LineChart lineChart;
    private Button startButton;
    private Button stopButton;
    private Button resetButton;
    private Button saveButton;
    private RadioGroup activityTypeRadioGroup;
    private RadioButton radioRunning, radioWalking;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView stepsTextView ;
    private Button loadCsv;

    private boolean recording = false;
    private List<String[]> sensorData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_terminal, container, false);
        fileNameEditText = rootView.findViewById(R.id.file_name_edit_text);
        stepsEditText = rootView.findViewById(R.id.steps_edit_text);
        lineChart = rootView.findViewById(R.id.line_chart);
        startButton = rootView.findViewById(R.id.start_button);
        stopButton = rootView.findViewById(R.id.stop_button);
        resetButton = rootView.findViewById(R.id.reset_button);
        saveButton = rootView.findViewById(R.id.save_button);
        stepsTextView = rootView.findViewById(R.id.stepsTextView);
        sensorManager = (SensorManager) requireActivity().getSystemService(requireActivity().SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        loadCsv = rootView.findViewById(R.id.load_csv_button);
        loadCsv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoadCSV.class);
                startActivity(intent);
            }
        });
        sensorData = new ArrayList<>();
        activityTypeRadioGroup = rootView.findViewById(R.id.activity_type_radio_group);
        radioRunning = rootView.findViewById(R.id.radio_running);
        radioWalking = rootView.findViewById(R.id.radio_walking);
        startButton.setOnClickListener(v -> {
            startRecording();
            setButtonStates(false, true, false, false);
        });

        stopButton.setOnClickListener(v -> {
            stopRecording();
            setButtonStates(true, false, true, true);
        });

        resetButton.setOnClickListener(v -> {
            resetRecording();
            setButtonStates(true, false, false, false);
        });

        saveButton.setOnClickListener(v -> {
            saveDataToFile();
            setButtonStates(true, false, true, false);
        });


        return rootView;
    }
    private void setButtonStates(boolean startEnabled, boolean stopEnabled, boolean resetEnabled, boolean saveEnabled) {
        startButton.setEnabled(startEnabled);
        stopButton.setEnabled(stopEnabled);
        resetButton.setEnabled(resetEnabled);
        saveButton.setEnabled(saveEnabled);
    }


    @Override
    public void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }


    @Override
    public void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
    private double calculateAccelerationNorm(double accX, double accY, double accZ) {
        return Math.sqrt(accX * accX + accY * accY + accZ * accZ);
    }




    private Queue<Double> window = new LinkedList<>();
    private double sum = 0;
    private int currentSteps = 0;

    private void processNewAccelerationData(double accX, double accY, double accZ) {
        final double THRESHOLD = 15.0;
        final int WINDOW_SIZE = 10;

        double norm = calculateAccelerationNorm(accX, accY, accZ);

        window.add(norm);
        sum += norm;

        if (window.size() > WINDOW_SIZE) {
            sum -= window.remove();
        }

        double average = sum / window.size();
        if (average > THRESHOLD) {
            currentSteps++;
            stepsTextView.setText("Steps: " + currentSteps);
        }
    }



    @Override
    public void onSensorChanged(SensorEvent event) {
        if (recording) {
            long timeMillis = System.currentTimeMillis();
            double timeSec = timeMillis / 1000.0;

            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            sensorData.add(new String[]{String.valueOf(timeSec), String.valueOf(x), String.valueOf(y), String.valueOf(z)});

            double n = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2));

           // sensorData.add(new String[]{String.valueOf(timeSec), String.valueOf(n)});
            updateLineChart(n);

            processNewAccelerationData(x, y, z);
        }
    }


    private void updateLineChart(double n) {
        LineData lineData = lineChart.getData();
        if (lineData == null) {
            lineData = new LineData();
            lineChart.setData(lineData);
        }

        LineDataSet dataSetN = createLineDataSet(lineData, "ACC N", Color.RED);
        dataSetN.addEntry(new Entry(dataSetN.getEntryCount(), (float) n));

        lineData.notifyDataChanged();
        lineChart.notifyDataSetChanged();
        lineChart.invalidate();
    }

    private void startRecording() {
        recording = true;
        sensorData.clear();
        currentSteps = 0;
        window.clear();
        sum = 0;
    }


    private void stopRecording() {
        recording = false;
    }

    private void resetRecording() {
        recording = false;
        sensorData.clear();
        if (lineChart.getData() != null) {
            lineChart.clearValues();
            lineChart.invalidate();
        }
        currentSteps = 0;
        stepsTextView.setText("Steps:0" );

        window.clear();
        sum = 0;
        //updateLineChart(0, 0, 0);
    }

    private void saveDataToFile() {
        if (sensorData.isEmpty()) {
            Toast.makeText(requireContext(), "No data to save", Toast.LENGTH_SHORT).show();
            return;
        }

        String fileName = fileNameEditText.getText().toString();

        if (fileName.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a file name", Toast.LENGTH_SHORT).show();
            return;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        String currentTime = dateFormat.format(new Date());
        String steps = stepsEditText.getText().toString();

        String activityType = "";
        if (activityTypeRadioGroup.getCheckedRadioButtonId() == R.id.radio_running) {
            activityType = "Running";
        } else if (activityTypeRadioGroup.getCheckedRadioButtonId() == R.id.radio_walking) {
            activityType = "Walking";
        }

        String[] header = {"Time [sec]", "ACC X", "ACC Y", "ACC Z"};

        String[] experimentInfo = {
                "NAME: " + fileName,
                "EXPERIMENT TIME: " + currentTime,
                "ACTIVITY TYPE: " + activityType,
                "COUNT OF ACTUAL STEPS: " + steps,
                "ESTIMATED STEPS: " + currentSteps,
                ""
        };

        // Save experimentInfo to a separate CSV file
        try {
            String experimentInfoFileName = "experimentInfo.csv";
            File experimentInfoFile = new File(requireContext().getExternalFilesDir(null), experimentInfoFileName);
            FileWriter experimentInfoFileWriter = new FileWriter(experimentInfoFile);
            CSVWriter experimentInfoCsvWriter = new CSVWriter(experimentInfoFileWriter);
            experimentInfoCsvWriter.writeNext(experimentInfo);
            experimentInfoCsvWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Error saving experiment info", Toast.LENGTH_SHORT).show();
        }

        // Save sensorData to the main CSV file
        try {
            File file = new File(requireContext().getExternalFilesDir(null), fileName + ".csv");
            FileWriter fileWriter = new FileWriter(file);
            CSVWriter csvWriter = new CSVWriter(fileWriter);

            csvWriter.writeNext(experimentInfo);
            csvWriter.writeNext(header);

            long startTimeMillis = System.currentTimeMillis();
            double startTimeSec = startTimeMillis / 1000.0;

            for (String[] data : sensorData) {
                long timeMillis = System.currentTimeMillis();
                double elapsedTimeSec = timeMillis / 1000.0 - startTimeSec;
                String[] newData = {String.valueOf(elapsedTimeSec), data[0], data[1], data[2]};
                csvWriter.writeNext(newData);
            }

            csvWriter.close();

            Toast.makeText(requireContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Error saving data", Toast.LENGTH_SHORT).show();
        }
    }




//    private void updateLineChart(float x, float y, float z) {
//        LineData lineData = lineChart.getData();
//        if (lineData == null) {
//            lineData = new LineData();
//            lineChart.setData(lineData);
//        }
//
//        LineDataSet dataSetX = createLineDataSet(lineData, "ACC X", Color.RED);
//        LineDataSet dataSetY = createLineDataSet(lineData, "ACC Y", Color.GREEN);
//        LineDataSet dataSetZ = createLineDataSet(lineData, "ACC Z", Color.BLUE);
//
//        dataSetX.addEntry(new Entry(dataSetX.getEntryCount(), x));
//        dataSetY.addEntry(new Entry(dataSetY.getEntryCount(), y));
//        dataSetZ.addEntry(new Entry(dataSetZ.getEntryCount(), z));
//
//        lineData.notifyDataChanged();
//        lineChart.notifyDataSetChanged();
//        lineChart.invalidate();
//    }

    private LineDataSet createLineDataSet(LineData lineData, String label, int color) {
        LineDataSet dataSet = (LineDataSet) lineData.getDataSetByLabel(label, false);
        if (dataSet == null) {
            dataSet = new LineDataSet(null, label);
            dataSet.setColor(color);
            dataSet.setDrawCircles(false);
            dataSet.setDrawValues(false);
            lineData.addDataSet(dataSet);
        }
        return dataSet;
    }

}
