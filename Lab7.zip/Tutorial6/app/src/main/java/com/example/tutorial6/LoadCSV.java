package com.example.tutorial6;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.util.ArrayList;

public class LoadCSV extends AppCompatActivity {

    private EditText csvFileNameEditText;
    private LineChart lineChart;
    private TextView estimatedStepsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_csv);

        csvFileNameEditText = findViewById(R.id.csv_file_name_edit_text);
        lineChart = findViewById(R.id.line_chart);
        estimatedStepsTextView = findViewById(R.id.estimated_steps_text_view);

        Button loadButton = findViewById(R.id.load_button);
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fileName = csvFileNameEditText.getText().toString();
                if (!fileName.isEmpty()) {
                    ArrayList<String[]> csvData = readCSVFile(getExternalFilesDir(null) + "/" + fileName);
                    if (csvData != null) {
                        LineData lineData = createLineData(csvData);
                        lineChart.setData(lineData);
                        lineChart.invalidate();
                    } else {
                        Toast.makeText(LoadCSV.this, "Error loading CSV file", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoadCSV.this, "Please enter a CSV file name", Toast.LENGTH_SHORT).show();
                }
            }
        });


        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private ArrayList<String[]> readCSVFile(String filePath) {
        try {
            CSVReader reader = new CSVReader(new FileReader(filePath));
            ArrayList<String[]> csvData = new ArrayList<>();
            String[] nextLine;
            boolean isHeaderFound = false;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length >= 2) {
                    String timeSec = nextLine[0];
                    String accelerationNorm = nextLine[1];
                    csvData.add(new String[]{timeSec, accelerationNorm});
                } else if (nextLine.length >= 1) {
                   
                     String line = nextLine[0];
                     if (line.startsWith("ESTIMATED STEPS: ")) {
                        String estimatedSteps = line.substring("ESTIMATED STEPS: ".length());

                        TextView estimatedStepsTextView = findViewById(R.id.estimated_steps_text_view);
                        estimatedStepsTextView.setText("Estimated Steps: " + estimatedSteps);
                    }
                }
            }
            reader.close();
            return csvData;
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("LoadCSV", "Error reading CSV file", e);
            return null;
        }
    }

    private LineData createLineData(ArrayList<String[]> csvData) {
        ArrayList<Entry> entriesX = new ArrayList<>();
        ArrayList<Entry> entriesY = new ArrayList<>();
        ArrayList<Entry> entriesZ = new ArrayList<>();

        for (int i = 0; i < csvData.size(); i++) {
            String[] data = csvData.get(i);
            try {
                float time = Float.parseFloat(data[0]);
                float x = Float.parseFloat(data[1]);
                float y = Float.parseFloat(data[2]);
                float z = Float.parseFloat(data[3]);

                entriesX.add(new Entry(time, x));
                entriesY.add(new Entry(time, y));
                entriesZ.add(new Entry(time, z));
            } catch (NumberFormatException e) {
                Log.e("LoadCSV", "Error parsing float", e);
            }
        }

        LineDataSet dataSetX = new LineDataSet(entriesX, "X");
        dataSetX.setColor(Color.RED);
        dataSetX.setDrawCircles(false);
        dataSetX.setDrawValues(false);

        LineDataSet dataSetY = new LineDataSet(entriesY, "Y");
        dataSetY.setColor(Color.GREEN);
        dataSetY.setDrawCircles(false);
        dataSetY.setDrawValues(false);

        LineDataSet dataSetZ = new LineDataSet(entriesZ, "Z");
        dataSetZ.setColor(Color.BLUE);
        dataSetZ.setDrawCircles(false);
        dataSetZ.setDrawValues(false);

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(dataSetX);
        dataSets.add(dataSetY);
        dataSets.add(dataSetZ);

        return new LineData(dataSets);
    }


}
